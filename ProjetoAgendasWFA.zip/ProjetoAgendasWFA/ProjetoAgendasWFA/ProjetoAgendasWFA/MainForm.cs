using ProjetoAgenda.Models;

namespace ProjetoAgendasWFA;

public sealed class MainForm : Form
{
    private readonly Contatos _agenda = new();
    private readonly ListBox _lista = new();
    private readonly Label _status = new();

    public MainForm()
    {
        Text = "Projeto Agenda — Contatos";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(850, 560);
        Size = new Size(980, 650);
        Font = new Font("Segoe UI", 10F);

        var titulo = new Label { Text = "04 — Projeto Agenda (Contatos)", Dock = DockStyle.Top, Height = 62, Font = new Font("Segoe UI", 18F, FontStyle.Bold), Padding = new Padding(22, 14, 0, 0) };
        var subtitulo = new Label { Text = "Gerenciamento de contatos pessoais", Location = new Point(25, 70), AutoSize = true, ForeColor = Color.DimGray };
        var opcoes = new GroupBox { Text = "Opções do Seletor", Location = new Point(22, 105), Size = new Size(360, 390), Padding = new Padding(15) };
        var listaGrupo = new GroupBox { Text = "Contatos cadastrados", Location = new Point(410, 105), Size = new Size(530, 390), Padding = new Padding(15) };

        var adicionar = CriarBotao("1. Adicionar contato", 20, 40);
        var pesquisar = CriarBotao("2. Pesquisar contato", 20, 100);
        var alterar = CriarBotao("3. Alterar contato", 20, 160);
        var remover = CriarBotao("4. Remover contato", 20, 220);
        var listar = CriarBotao("5. Listar contatos", 20, 280);
        var sair = CriarBotao("0. Sair", 20, 340);
        adicionar.Click += (_, _) => AdicionarContato();
        pesquisar.Click += (_, _) => PesquisarContato();
        alterar.Click += (_, _) => AlterarContato();
        remover.Click += (_, _) => RemoverContato();
        listar.Click += (_, _) => AtualizarLista();
        sair.Click += (_, _) => Close();
        opcoes.Controls.AddRange(new Control[] { adicionar, pesquisar, alterar, remover, listar, sair });

        _lista.Dock = DockStyle.Fill;
        _lista.HorizontalScrollbar = true;
        _lista.SelectedIndexChanged += (_, _) => ExibirSelecionado();
        listaGrupo.Controls.Add(_lista);

        _status.Text = "Nenhum contato cadastrado.";
        _status.Location = new Point(25, 525);
        _status.AutoSize = true;
        _status.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        Controls.AddRange(new Control[] { titulo, subtitulo, opcoes, listaGrupo, _status });
    }

    private static Button CriarBotao(string texto, int x, int y) => new() { Text = texto, Location = new Point(x, y), Size = new Size(300, 45), FlatStyle = FlatStyle.System };

    private void AdicionarContato()
    {
        using var tela = new ContatoForm("Adicionar contato");
        if (tela.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            if (!_agenda.Adicionar(tela.Contato!))
            {
                Avisar("Já existe um contato com este e-mail.");
                return;
            }
            AtualizarLista();
            Informar("Contato adicionado com sucesso.");
        }
        catch (ArgumentException ex) { Avisar(ex.Message); }
    }

    private void PesquisarContato()
    {
        var contato = SelecionarContato("Pesquisar contato");
        if (contato is null) return;
        MessageBox.Show(MontarDetalhes(contato), "Dados do contato", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void AlterarContato()
    {
        var atual = SelecionarContato("Alterar contato");
        if (atual is null) return;
        using var tela = new ContatoForm("Alterar contato", atual);
        if (tela.ShowDialog(this) != DialogResult.OK) return;
        try
        {
            var novo = tela.Contato!;
            if (!string.Equals(atual.Email, novo.Email, StringComparison.OrdinalIgnoreCase) && _agenda.Pesquisar(novo) is not null)
            {
                Avisar("Já existe outro contato com este e-mail.");
                return;
            }
            if (!string.Equals(atual.Email, novo.Email, StringComparison.OrdinalIgnoreCase))
            {
                _agenda.Remover(atual);
                _agenda.Adicionar(novo);
            }
            else
            {
                _agenda.Alterar(novo);
            }
            AtualizarLista();
            Informar("Contato alterado com sucesso.");
        }
        catch (ArgumentException ex) { Avisar(ex.Message); }
    }

    private void RemoverContato()
    {
        var contato = SelecionarContato("Remover contato");
        if (contato is null) return;
        if (MessageBox.Show($"Remover o contato {contato.Nome}?", "Confirmar remoção", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
        {
            _agenda.Remover(contato);
            AtualizarLista();
            Informar("Contato removido.");
        }
    }

    private Contato? SelecionarContato(string titulo)
    {
        if (_agenda.Agenda.Count == 0) { Avisar("Nenhum contato cadastrado."); return null; }
        using var tela = new SelecaoForm(titulo, _agenda.Agenda);
        return tela.ShowDialog(this) == DialogResult.OK ? tela.Selecionado : null;
    }

    private void AtualizarLista()
    {
        _lista.Items.Clear();
        foreach (var contato in _agenda.Agenda) _lista.Items.Add(contato);
        _status.Text = _agenda.Agenda.Count == 0 ? "Nenhum contato cadastrado." : $"Total de contatos: {_agenda.Agenda.Count}";
    }

    private void ExibirSelecionado()
    {
        if (_lista.SelectedItem is Contato contato) _status.Text = MontarDetalhes(contato).Replace(Environment.NewLine, " | ");
    }

    private static string MontarDetalhes(Contato contato)
    {
        var telefones = contato.Telefones.Count == 0 ? "Nenhum" : string.Join(Environment.NewLine, contato.Telefones.Select(t => $"  • {t}"));
        return $"Nome: {contato.Nome}{Environment.NewLine}E-mail: {contato.Email}{Environment.NewLine}Nascimento: {contato.DtNasc}{Environment.NewLine}Idade: {contato.GetIdade()}{Environment.NewLine}Telefones:{Environment.NewLine}{telefones}";
    }

    private static void Avisar(string mensagem) => MessageBox.Show(mensagem, "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
    private static void Informar(string mensagem) => MessageBox.Show(mensagem, "Agenda", MessageBoxButtons.OK, MessageBoxIcon.Information);
}

internal sealed class ContatoForm : Form
{
    private readonly TextBox _nome = new();
    private readonly TextBox _email = new();
    private readonly DateTimePicker _nascimento = new() { Format = DateTimePickerFormat.Short, MaxDate = DateTime.Today };
    private readonly TextBox _tipo = new();
    private readonly TextBox _numero = new();
    private readonly CheckBox _principal = new() { Text = "Telefone principal" };
    private readonly ListBox _telefones = new();
    private readonly List<Telefone> _listaTelefones = new();
    private readonly Contato? _original;
    public Contato? Contato { get; private set; }

    public ContatoForm(string titulo, Contato? original = null)
    {
        _original = original;
        Text = titulo;
        Width = 500; Height = 520; StartPosition = FormStartPosition.CenterParent; FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;
        var campos = new[] { ("Nome:", _nome, 20), ("E-mail:", _email, 65), ("Tipo:", _tipo, 155), ("Número:", _numero, 200) };
        foreach (var (texto, caixa, y) in campos) { var label = new Label { Text = texto, Location = new Point(22, y + 3), AutoSize = true }; caixa.Location = new Point(125, y); caixa.Width = 320; Controls.AddRange(new Control[] { label, caixa }); }
        var dataLabel = new Label { Text = "Nascimento:", Location = new Point(22, 110), AutoSize = true }; _nascimento.Location = new Point(125, 107); Controls.AddRange(new Control[] { dataLabel, _nascimento });
        _principal.Location = new Point(125, 245); Controls.Add(_principal);
        var add = new Button { Text = "Adicionar telefone", Location = new Point(125, 280), Width = 160 }; add.Click += (_, _) => AdicionarTelefone(); Controls.Add(add);
        _telefones.Location = new Point(22, 325); _telefones.Size = new Size(423, 110); Controls.Add(_telefones);
        var ok = new Button { Text = "Salvar", DialogResult = DialogResult.OK, Location = new Point(260, 460), Width = 85 }; ok.Click += (_, e) => { if (!Salvar()) { DialogResult = DialogResult.None; } }; var cancelar = new Button { Text = "Cancelar", DialogResult = DialogResult.Cancel, Location = new Point(360, 460), Width = 85 }; Controls.AddRange(new Control[] { ok, cancelar }); AcceptButton = ok; CancelButton = cancelar;
        if (original is not null) Preencher(original);
    }

    private void Preencher(Contato c) { _nome.Text = c.Nome; _email.Text = c.Email; _nascimento.Value = c.DtNasc.ToDateTime(); _listaTelefones.AddRange(c.Telefones.Select(t => new Telefone(t.Tipo, t.Numero, t.Principal))); AtualizarTelefones(); }
    private void AdicionarTelefone() { if (string.IsNullOrWhiteSpace(_tipo.Text) || string.IsNullOrWhiteSpace(_numero.Text)) { MessageBox.Show("Informe o tipo e o número."); return; } if (_principal.Checked) foreach (var t in _listaTelefones) t.Principal = false; var telefone = new Telefone(_tipo.Text, _numero.Text, _principal.Checked || _listaTelefones.Count == 0); _listaTelefones.Add(telefone); _tipo.Clear(); _numero.Clear(); _principal.Checked = false; AtualizarTelefones(); }
    private void AtualizarTelefones() { _telefones.Items.Clear(); foreach (var t in _listaTelefones) _telefones.Items.Add(t); }
    private bool Salvar() { try { var data = _nascimento.Value; var contato = new Contato(_email.Text, _nome.Text, new Data(data.Day, data.Month, data.Year)); foreach (var t in _listaTelefones) contato.AdicionarTelefone(t); Contato = contato; return true; } catch (ArgumentException ex) { MessageBox.Show(ex.Message, "Validação"); return false; } }
}

internal sealed class SelecaoForm : Form
{
    private readonly ListBox _lista = new();
    public Contato? Selecionado => _lista.SelectedItem as Contato;
    public SelecaoForm(string titulo, IReadOnlyList<Contato> contatos)
    {
        Text = titulo; Width = 600; Height = 350; StartPosition = FormStartPosition.CenterParent; FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;
        _lista.Dock = DockStyle.Top; _lista.Height = 220; foreach (var contato in contatos) _lista.Items.Add(contato); Controls.Add(_lista);
        var ok = new Button { Text = "Selecionar", DialogResult = DialogResult.OK, Location = new Point(380, 245), Width = 90 }; ok.Click += (_, e) => { if (_lista.SelectedIndex < 0) { MessageBox.Show("Selecione um contato."); DialogResult = DialogResult.None; } }; var cancelar = new Button { Text = "Cancelar", DialogResult = DialogResult.Cancel, Location = new Point(480, 245), Width = 90 }; Controls.AddRange(new Control[] { ok, cancelar }); AcceptButton = ok; CancelButton = cancelar;
    }
}
