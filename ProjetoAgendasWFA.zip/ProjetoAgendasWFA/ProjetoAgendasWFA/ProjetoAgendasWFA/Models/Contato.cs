namespace ProjetoAgenda.Models;

public class Contato
{
    private string _email = string.Empty;
    private string _nome = string.Empty;
    private Data _dtNasc = null!;
    private readonly List<Telefone> _telefones = new();

    public Contato(string email, string nome, Data dtNasc)
    {
        Email = email;
        Nome = nome;
        DtNasc = dtNasc;
    }

    public string Email { get => _email; set => _email = ValidarTexto(value, "O e-mail é obrigatório."); }
    public string Nome { get => _nome; set => _nome = ValidarTexto(value, "O nome é obrigatório."); }
    public Data DtNasc { get => _dtNasc; set => _dtNasc = value ?? throw new ArgumentNullException(nameof(value)); }
    public IReadOnlyList<Telefone> Telefones => _telefones.AsReadOnly();

    public int GetIdade()
    {
        var hoje = DateTime.Today;
        var idade = hoje.Year - DtNasc.ToDateTime().Year;
        if (DtNasc.ToDateTime().Date > hoje.AddYears(-idade).Date) idade--;
        return idade;
    }

    public void AdicionarTelefone(Telefone t)
    {
        ArgumentNullException.ThrowIfNull(t);
        if (t.Principal)
        {
            foreach (var telefone in _telefones) telefone.Principal = false;
        }
        else if (_telefones.Count == 0)
        {
            t.Principal = true;
        }
        _telefones.Add(t);
    }

    public string GetTelefonePrincipal() => _telefones.FirstOrDefault(t => t.Principal)?.Numero ?? "Não informado";

    public override string ToString() => $"{Nome} | {Email} | Nascimento: {DtNasc} | Idade: {GetIdade()} | Tel. principal: {GetTelefonePrincipal()}";

    public override bool Equals(object? obj) => obj is Contato outro && string.Equals(Email, outro.Email, StringComparison.OrdinalIgnoreCase);
    public override int GetHashCode() => StringComparer.OrdinalIgnoreCase.GetHashCode(Email);

    private static string ValidarTexto(string valor, string mensagem) => string.IsNullOrWhiteSpace(valor) ? throw new ArgumentException(mensagem) : valor.Trim();
}
