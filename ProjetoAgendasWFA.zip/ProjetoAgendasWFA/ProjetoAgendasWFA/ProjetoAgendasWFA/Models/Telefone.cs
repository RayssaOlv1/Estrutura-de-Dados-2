namespace ProjetoAgenda.Models;

public class Telefone
{
    private string _tipo;
    private string _numero;
    private bool _principal;

    public Telefone(string tipo, string numero, bool principal = false)
    {
        if (string.IsNullOrWhiteSpace(tipo)) throw new ArgumentException("O tipo do telefone é obrigatório.", nameof(tipo));
        if (string.IsNullOrWhiteSpace(numero)) throw new ArgumentException("O número do telefone é obrigatório.", nameof(numero));

        _tipo = tipo.Trim();
        _numero = numero.Trim();
        _principal = principal;
    }

    public string Tipo { get => _tipo; set => _tipo = value.Trim(); }
    public string Numero { get => _numero; set => _numero = value.Trim(); }
    public bool Principal { get => _principal; set => _principal = value; }

    public override string ToString() => $"{Tipo}: {Numero}" + (Principal ? " (principal)" : string.Empty);
}
