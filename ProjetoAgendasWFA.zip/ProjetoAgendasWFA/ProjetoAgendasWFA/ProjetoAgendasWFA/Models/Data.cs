namespace ProjetoAgenda.Models;

public class Data
{
    private int _dia;
    private int _mes;
    private int _ano;

    public Data(int dia, int mes, int ano)
    {
        SetData(dia, mes, ano);
    }

    public void SetData(int dia, int mes, int ano)
    {
        if (ano < 1 || mes < 1 || mes > 12 || dia < 1)
            throw new ArgumentException("Data inválida.");

        try
        {
            _ = new DateTime(ano, mes, dia);
        }
        catch (ArgumentOutOfRangeException)
        {
            throw new ArgumentException("Data inválida.");
        }

        _dia = dia;
        _mes = mes;
        _ano = ano;
    }

    public DateTime ToDateTime() => new(_ano, _mes, _dia);

    public override string ToString() => $"{_dia:00}/{_mes:00}/{_ano:0000}";
}
