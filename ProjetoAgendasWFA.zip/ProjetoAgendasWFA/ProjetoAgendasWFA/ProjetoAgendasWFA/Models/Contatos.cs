namespace ProjetoAgenda.Models;

public class Contatos
{
    private readonly List<Contato> _agenda = new();

    public IReadOnlyList<Contato> Agenda => _agenda.AsReadOnly();

    public bool Adicionar(Contato c)
    {
        ArgumentNullException.ThrowIfNull(c);
        if (Pesquisar(c) is not null) return false;
        _agenda.Add(c);
        return true;
    }

    public Contato? Pesquisar(Contato c)
    {
        ArgumentNullException.ThrowIfNull(c);
        return _agenda.FirstOrDefault(contato => contato.Equals(c));
    }

    public bool Alterar(Contato c)
    {
        ArgumentNullException.ThrowIfNull(c);
        var indice = _agenda.FindIndex(contato => contato.Equals(c));
        if (indice < 0) return false;
        _agenda[indice] = c;
        return true;
    }

    public bool Remover(Contato c)
    {
        ArgumentNullException.ThrowIfNull(c);
        return _agenda.Remove(c);
    }
}
