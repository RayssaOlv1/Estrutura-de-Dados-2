using ProjetoAtendimento.Models;

namespace ProjetoAtendimento;

public sealed class MainForm : Form
{
    private readonly Senhas _senhas = new();
    private readonly Guiches _guiches = new();
    private readonly ComboBox _seletorGuiche = new();
    private readonly ListBox _fila = new();
    private readonly ListBox _atendimentos = new();
    private readonly Label _status = new();

    public MainForm()
    {
        Text = "Projeto Atendimento";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(940, 600);
        Size = new Size(1100, 720);
        Font = new Font("Segoe UI", 10F);

        var titulo = new Label { Text = "08 — Projeto Atendimento", Dock = DockStyle.Top, Height = 62, Font = new Font("Segoe UI", 18F, FontStyle.Bold), Padding = new Padding(22, 14, 0, 0) };
        var subtitulo = new Label { Text = "Controle de fila de espera e histórico de atendimentos", Location = new Point(25, 70), AutoSize = true, ForeColor = Color.DimGray };
        var grupoAcoes = new GroupBox { Text = "Funcionalidades", Location = new Point(22, 105), Size = new Size(420, 425), Padding = new Padding(15) };
        var grupoFila = new GroupBox { Text = "Senhas geradas — aguardando atendimento", Location = new Point(470, 105), Size = new Size(590, 255), Padding = new Padding(15) };
        var grupoHistorico = new GroupBox { Text = "Atendimentos realizados por guichê", Location = new Point(470, 380), Size = new Size(590, 280), Padding = new Padding(15) };

        var gerar = CriarBotao("Gerar senha", 20, 35);
        var cadastrar = CriarBotao("Cadastrar novo guichê", 20, 95);
        var chamar = CriarBotao("Chamar próxima senha", 20, 155);
        var atualizar = CriarBotao("Atualizar listas", 20, 215);
        gerar.Click += (_, _) => GerarSenha();
        cadastrar.Click += (_, _) => CadastrarGuiches();
        chamar.Click += (_, _) => ChamarSenha();
        atualizar.Click += (_, _) => AtualizarListas();
        grupoAcoes.Controls.AddRange(new Control[] { gerar, cadastrar, chamar, atualizar });

        var labelGuiche = new Label { Text = "Guichê:", Location = new Point(20, 285), AutoSize = true };
        _seletorGuiche.DropDownStyle = ComboBoxStyle.DropDownList;
        _seletorGuiche.Location = new Point(85, 281);
        _seletorGuiche.Width = 250;
        grupoAcoes.Controls.AddRange(new Control[] { labelGuiche, _seletorGuiche });

        _fila.Dock = DockStyle.Fill;
        grupoFila.Controls.Add(_fila);
        _atendimentos.Dock = DockStyle.Fill;
        grupoHistorico.Controls.Add(_atendimentos);

        _status.Text = "Cadastre os guichês e gere uma senha para começar.";
        _status.Location = new Point(25, 555);
        _status.AutoSize = true;
        _status.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        Controls.AddRange(new Control[] { titulo, subtitulo, grupoAcoes, grupoFila, grupoHistorico, _status });
    }

    private static Button CriarBotao(string texto, int x, int y) => new() { Text = texto, Location = new Point(x, y), Size = new Size(350, 45), FlatStyle = FlatStyle.System };

    private void GerarSenha()
    {
        var senha = _senhas.Gerar();
        AtualizarListas();
        Informar($"Senha {senha.Id} gerada e adicionada à fila.");
    }

    private void CadastrarGuiches()
    {
        using var dialogo = new Form { Text = "Cadastrar guichês", Width = 380, Height = 180, StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false };
        var label = new Label { Text = "Quantidade de guichês a adicionar:", AutoSize = true, Location = new Point(18, 18) };
        var quantidade = new NumericUpDown { Minimum = 1, Maximum = 20, Value = 1, Location = new Point(18, 48), Width = 310 };
        var ok = new Button { Text = "Adicionar", DialogResult = DialogResult.OK, Location = new Point(165, 88), Width = 85 };
        var cancelar = new Button { Text = "Cancelar", DialogResult = DialogResult.Cancel, Location = new Point(255, 88), Width = 85 };
        dialogo.Controls.AddRange(new Control[] { label, quantidade, ok, cancelar });
        dialogo.AcceptButton = ok; dialogo.CancelButton = cancelar;
        if (dialogo.ShowDialog(this) != DialogResult.OK) return;
        var primeiroId = _guiches.ListaGuiches.Count + 1;
        for (var i = 0; i < quantidade.Value; i++) _guiches.Adicionar(new Guiche(primeiroId + i));
        AtualizarSeletorGuiches();
        Informar($"{quantidade.Value} guichê(s) cadastrado(s).");
    }

    private void ChamarSenha()
    {
        if (_guiches.ListaGuiches.Count == 0) { Avisar("Cadastre pelo menos um guichê."); return; }
        if (_seletorGuiche.SelectedIndex < 0) { Avisar("Selecione o guichê que fará o atendimento."); return; }
        if (_senhas.Quantidade == 0) { Avisar("Não há senhas aguardando atendimento."); return; }
        var guiche = _guiches.ListaGuiches[_seletorGuiche.SelectedIndex];
        if (_senhas.Chamar(guiche))
        {
            AtualizarListas();
            Informar($"A próxima senha foi chamada pelo {guiche}.");
        }
    }

    private void AtualizarListas()
    {
        _fila.Items.Clear();
        foreach (var senha in _senhas.FilaSenhas) _fila.Items.Add(senha.DadosParciais());
        _atendimentos.Items.Clear();
        foreach (var guiche in _guiches.ListaGuiches)
        {
            foreach (var senha in guiche.Atendimentos) _atendimentos.Items.Add($"{guiche}: {senha.DadosCompletos()}");
        }
        _status.Text = $"Senhas aguardando: {_senhas.Quantidade} | Guichês cadastrados: {_guiches.ListaGuiches.Count}";
    }

    private void AtualizarSeletorGuiches()
    {
        var selecionado = _seletorGuiche.SelectedIndex;
        _seletorGuiche.Items.Clear();
        foreach (var guiche in _guiches.ListaGuiches) _seletorGuiche.Items.Add(guiche);
        if (_seletorGuiche.Items.Count > 0) _seletorGuiche.SelectedIndex = selecionado >= 0 && selecionado < _seletorGuiche.Items.Count ? selecionado : 0;
        AtualizarListas();
    }

    private static void Avisar(string mensagem) => MessageBox.Show(mensagem, "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
    private static void Informar(string mensagem) => MessageBox.Show(mensagem, "Projeto Atendimento", MessageBoxButtons.OK, MessageBoxIcon.Information);
}
