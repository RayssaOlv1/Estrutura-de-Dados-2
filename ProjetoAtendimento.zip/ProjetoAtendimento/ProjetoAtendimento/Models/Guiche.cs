namespace ProjetoAtendimento.Models;

public class Guiche
{
    private readonly int _id;
    private readonly Queue<Senha> _atendimentos;

    public Guiche() : this(0) { }

    public Guiche(int id)
    {
        _id = id;
        _atendimentos = new Queue<Senha>();
    }

    public int Id => _id;
    public IReadOnlyCollection<Senha> Atendimentos => _atendimentos.ToArray();

    public bool Chamar(Queue<Senha> filaSenhas)
    {
        ArgumentNullException.ThrowIfNull(filaSenhas);
        if (filaSenhas.Count == 0) return false;
        var senha = filaSenhas.Dequeue();
        senha.RegistrarAtendimento();
        _atendimentos.Enqueue(senha);
        return true;
    }

    public override string ToString() => $"Guichê {_id}";
}
