namespace ProjetoAtendimento.Models;

public class Guiches
{
    private readonly List<Guiche> _listaGuiches;

    public Guiches() => _listaGuiches = new List<Guiche>();

    public IReadOnlyList<Guiche> ListaGuiches => _listaGuiches.AsReadOnly();

    public void Adicionar(Guiche guiche)
    {
        ArgumentNullException.ThrowIfNull(guiche);
        _listaGuiches.Add(guiche);
    }
}
