namespace ProjetoAtendimento.Models;

public class Senha
{
    private readonly int _id;
    private readonly DateTime _dataGerac;
    private readonly DateTime _horaGerac;
    private DateTime? _dataAtend;
    private DateTime? _horaAtend;

    public Senha(int id)
    {
        _id = id;
        _dataGerac = DateTime.Now;
        _horaGerac = _dataGerac;
    }

    public int Id => _id;
    public DateTime DataGerac => _dataGerac;
    public DateTime HoraGerac => _horaGerac;
    public DateTime? DataAtend => _dataAtend;
    public DateTime? HoraAtend => _horaAtend;
    public bool FoiAtendida => _horaAtend.HasValue;

    public void RegistrarAtendimento()
    {
        _dataAtend = DateTime.Now.Date;
        _horaAtend = DateTime.Now;
    }

    public string DadosParciais() => $"Senha {_id} - gerada em {_dataGerac:dd/MM/yyyy} às {_horaGerac:HH:mm:ss}";
    public string DadosCompletos() => $"Senha {_id} - gerada em {_dataGerac:dd/MM/yyyy HH:mm:ss} - atendida em {_dataAtend:dd/MM/yyyy} às {_horaAtend:HH:mm:ss}";
    public override string ToString() => FoiAtendida ? DadosCompletos() : DadosParciais();
}
