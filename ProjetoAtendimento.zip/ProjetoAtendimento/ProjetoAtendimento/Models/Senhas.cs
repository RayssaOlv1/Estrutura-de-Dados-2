namespace ProjetoAtendimento.Models;

public class Senhas
{
    private int _proximoAtendimento;
    private readonly Queue<Senha> _filaSenhas;

    public Senhas()
    {
        _proximoAtendimento = 1;
        _filaSenhas = new Queue<Senha>();
    }

    public IReadOnlyCollection<Senha> FilaSenhas => _filaSenhas.ToArray();
    public int Quantidade => _filaSenhas.Count;

    public Senha Gerar()
    {
        var senha = new Senha(_proximoAtendimento++);
        _filaSenhas.Enqueue(senha);
        return senha;
    }

    public bool Chamar(Guiche guiche)
    {
        ArgumentNullException.ThrowIfNull(guiche);
        return guiche.Chamar(_filaSenhas);
    }

    public bool TentarRetirar(out Senha? senha)
    {
        if (_filaSenhas.Count == 0)
        {
            senha = null;
            return false;
        }
        senha = _filaSenhas.Dequeue();
        return true;
    }
}
