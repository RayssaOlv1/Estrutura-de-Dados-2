namespace ProjetoRestaurante.Models;

public class Restaurante
{
    public const int LimitePedidos = 50;
    private readonly List<Pedido> _pedidos = new();
    private int _proximoPedido = 1;

    public IReadOnlyList<Pedido> Pedidos => _pedidos.AsReadOnly();

    public bool NovoPedido(Pedido pedido)
    {
        if (pedido is null || _pedidos.Count >= LimitePedidos) return false;
        _pedidos.Add(pedido);
        _proximoPedido = Math.Max(_proximoPedido, pedido.Id + 1);
        return true;
    }

    public int ProximoId() => _proximoPedido++;

    public Pedido? BuscarPedido(int id) => _pedidos.FirstOrDefault(pedido => pedido.Id == id);

    public bool CancelarPedido(Pedido pedido)
    {
        if (pedido is null || !_pedidos.Contains(pedido) || pedido.Cancelado) return false;
        pedido.Cancelar();
        return true;
    }

    public decimal TotalDoDia() => _pedidos.Where(pedido => !pedido.Cancelado).Sum(pedido => pedido.CalcularTotal());
}
