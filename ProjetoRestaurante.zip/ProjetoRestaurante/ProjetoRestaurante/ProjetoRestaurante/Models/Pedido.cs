namespace ProjetoRestaurante.Models;

public class Pedido
{
    public const int LimiteItens = 10;
    private readonly List<Item> _itens = new();

    public int Id { get; }
    public string Cliente { get; }
    public IReadOnlyList<Item> Itens => _itens.AsReadOnly();
    public bool Cancelado { get; private set; }

    public Pedido(int id, string cliente)
    {
        if (id <= 0) throw new ArgumentException("O id deve ser maior que zero.", nameof(id));
        if (string.IsNullOrWhiteSpace(cliente)) throw new ArgumentException("O cliente é obrigatório.", nameof(cliente));

        Id = id;
        Cliente = cliente.Trim();
    }

    public bool AdicionarItem(Item item)
    {
        if (Cancelado || item is null || _itens.Count >= LimiteItens) return false;
        _itens.Add(item);
        return true;
    }

    public bool RemoverItem(Item item)
    {
        if (Cancelado || item is null) return false;
        return _itens.Remove(item);
    }

    public decimal CalcularTotal() => _itens.Sum(item => item.Preco);

    public void Cancelar() => Cancelado = true;

    public override string ToString() => $"Pedido #{Id} - {Cliente} - {CalcularTotal():C}" + (Cancelado ? " (CANCELADO)" : string.Empty);
}
