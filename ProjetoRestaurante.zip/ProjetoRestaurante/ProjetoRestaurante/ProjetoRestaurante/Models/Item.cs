namespace ProjetoRestaurante.Models;

public class Item
{
    public int Id { get; }
    public string Descricao { get; }
    public decimal Preco { get; }

    public Item(int id, string descricao, decimal preco)
    {
        if (id <= 0) throw new ArgumentException("O id deve ser maior que zero.", nameof(id));
        if (string.IsNullOrWhiteSpace(descricao)) throw new ArgumentException("A descrição é obrigatória.", nameof(descricao));
        if (preco < 0) throw new ArgumentOutOfRangeException(nameof(preco), "O preço não pode ser negativo.");

        Id = id;
        Descricao = descricao.Trim();
        Preco = preco;
    }

    public override string ToString() => $"{Descricao} - {Preco:C}";
}
