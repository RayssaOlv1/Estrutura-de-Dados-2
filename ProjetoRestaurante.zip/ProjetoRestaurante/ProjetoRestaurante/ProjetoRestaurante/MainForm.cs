using ProjetoRestaurante.Models;

namespace ProjetoRestaurante;

public sealed class MainForm : Form
{
    private readonly Restaurante _restaurante = new();
    private readonly ComboBox _seletor = new();
    private readonly ListBox _listaPedidos = new();
    private readonly ListBox _listaItens = new();
    private readonly Label _resumo = new();
    private Pedido? _pedidoAtual; // ? <-- Serve para mostrar que a variável pode ser nula, sem quebrar o programa

    public MainForm()
    {
        Text = "Projeto Restaurante";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(820, 540);
        Size = new Size(980, 650);
        Font = new Font("Segoe UI", 10F);

        var titulo = new Label { Text = "03 — Projeto Restaurante", Dock = DockStyle.Top, Height = 55, Font = new Font("Segoe UI", 18F, FontStyle.Bold), Padding = new Padding(18, 12, 0, 0) };
        var menuLabel = new Label { Text = "Opções do Seletor", AutoSize = true, Location = new Point(20, 72), Font = new Font("Segoe UI", 11F, FontStyle.Bold) };
        _seletor.DropDownStyle = ComboBoxStyle.DropDownList;
        _seletor.Items.AddRange(new object[] { "0. Sair", "1. Criar novo pedido", "2. Adicionar item ao pedido", "3. Remover item do pedido", "4. Consultar pedido (mostrar id, cliente, itens e valor total)", "5. Cancelar pedido", "6. Listar todos os pedidos (com id, valores totais e soma geral do dia)" });
        _seletor.SelectedIndex = 0;
        _seletor.Location = new Point(20, 100);
        _seletor.Width = 640;
        _seletor.SelectedIndexChanged += (_, _) => ExecutarOpcao(_seletor.SelectedIndex);

        var pedidosLabel = new Label { Text = "Histórico de pedidos", AutoSize = true, Location = new Point(20, 155), Font = new Font("Segoe UI", 11F, FontStyle.Bold) };
        _listaPedidos.Location = new Point(20, 185);
        _listaPedidos.Size = new Size(430, 330);
        _listaPedidos.SelectedIndexChanged += (_, _) => SelecionarPedidoDaLista();

        var itensLabel = new Label { Text = "Itens do pedido selecionado", AutoSize = true, Location = new Point(480, 155), Font = new Font("Segoe UI", 11F, FontStyle.Bold) };
        _listaItens.Location = new Point(480, 185);
        _listaItens.Size = new Size(450, 250);

        _resumo.Location = new Point(480, 455);
        _resumo.AutoSize = true;
        _resumo.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
        _resumo.Text = "Nenhum pedido selecionado.";

        var dica = new Label { Text = "Selecione uma opção acima para operar o sistema.", AutoSize = true, Location = new Point(20, 535), ForeColor = Color.DimGray };
        Controls.AddRange(new Control[] { titulo, menuLabel, _seletor, pedidosLabel, _listaPedidos, itensLabel, _listaItens, _resumo, dica });
    }

    private void ExecutarOpcao(int opcao)
    {
        switch (opcao)
        {
            case 0:
                if (MessageBox.Show("Deseja sair do sistema?", "Confirmar saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    Close();
                break;
            case 1: CriarPedido(); break;
            case 2: AdicionarItem(); break;
            case 3: RemoverItem(); break;
            case 4: ConsultarPedido(); break;
            case 5: CancelarPedido(); break;
            case 6: ListarPedidos(); break;
        }
        _seletor.SelectedIndex = 0;
    }

    private void CriarPedido()
    {
        if (_restaurante.Pedidos.Count >= Restaurante.LimitePedidos)
        {
            Avisar("O limite de 50 pedidos foi atingido.");
            return;
        }

        var cliente = SolicitarTexto("Novo pedido", "Nome do cliente:");
        if (string.IsNullOrWhiteSpace(cliente)) return;

        var pedido = new Pedido(_restaurante.ProximoId(), cliente);
        _restaurante.NovoPedido(pedido);
        _pedidoAtual = pedido;
        AtualizarTela();
        Informar($"Pedido #{pedido.Id} criado com sucesso.");
    }

    private void AdicionarItem()
    {
        var pedido = ObterPedidoParaOperacao();
        if (pedido is null) return;
        if (pedido.Itens.Count >= Pedido.LimiteItens) { Avisar("Cada pedido pode ter no máximo 10 itens."); return; }

        var descricao = SolicitarTexto("Adicionar item", "Descrição do item:");
        if (string.IsNullOrWhiteSpace(descricao)) return;
        var precoTexto = SolicitarTexto("Adicionar item", "Preço (ex.: 12,50):");
        if (!decimal.TryParse(precoTexto, out var preco) || preco < 0) { Avisar("Informe um preço válido."); return; }

        var item = new Item(pedido.Itens.Count + 1, descricao, preco);
        pedido.AdicionarItem(item);
        AtualizarTela();
    }

    private void RemoverItem()
    {
        var pedido = ObterPedidoParaOperacao();
        if (pedido is null || pedido.Itens.Count == 0) { Avisar("O pedido não possui itens."); return; }
        if (_listaItens.SelectedIndex < 0) { Avisar("Selecione um item na lista de itens."); return; }
        pedido.RemoverItem(pedido.Itens[_listaItens.SelectedIndex]);
        AtualizarTela();
    }

    private void ConsultarPedido()
    {
        var pedido = ObterPedidoParaOperacao();
        if (pedido is null) return;
        var itens = pedido.Itens.Count == 0 ? "Nenhum item" : string.Join(Environment.NewLine, pedido.Itens.Select(item => $"  • {item}"));
        MessageBox.Show($"Id: {pedido.Id}{Environment.NewLine}Cliente: {pedido.Cliente}{Environment.NewLine}Status: {(pedido.Cancelado ? "Cancelado" : "Ativo")}{Environment.NewLine}{Environment.NewLine}Itens:{Environment.NewLine}{itens}{Environment.NewLine}{Environment.NewLine}Valor total: {pedido.CalcularTotal():C}", "Consulta do pedido", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void CancelarPedido()
    {
        var pedido = ObterPedidoParaOperacao();
        if (pedido is null) return;
        if (_restaurante.CancelarPedido(pedido)) { AtualizarTela(); Informar($"Pedido #{pedido.Id} cancelado."); }
        else Avisar("Não foi possível cancelar este pedido.");
    }

    private void ListarPedidos()
    {
        if (_restaurante.Pedidos.Count == 0) { Informar("Nenhum pedido cadastrado."); return; }
        var texto = string.Join(Environment.NewLine, _restaurante.Pedidos.Select(p => $"Pedido #{p.Id} | Cliente: {p.Cliente} | Total: {p.CalcularTotal():C} | {(p.Cancelado ? "Cancelado" : "Ativo")}"));
        MessageBox.Show(texto + Environment.NewLine + Environment.NewLine + $"Soma geral do dia (pedidos ativos): {_restaurante.TotalDoDia():C}", "Todos os pedidos", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private Pedido? ObterPedidoParaOperacao()
    {
        if (_pedidoAtual is not null) return _pedidoAtual;
        if (_restaurante.Pedidos.Count == 0) { Avisar("Crie um pedido primeiro."); return null; }
        return _restaurante.Pedidos.Last();
    }

    private void SelecionarPedidoDaLista()
    {
        if (_listaPedidos.SelectedIndex >= 0 && _listaPedidos.SelectedIndex < _restaurante.Pedidos.Count)
        {
            _pedidoAtual = _restaurante.Pedidos[_listaPedidos.SelectedIndex];
            AtualizarItens();
        }
    }

    private void AtualizarTela()
    {
        _listaPedidos.Items.Clear();
        foreach (var pedido in _restaurante.Pedidos) _listaPedidos.Items.Add(pedido);
        if (_pedidoAtual is not null) _listaPedidos.SelectedIndex = _restaurante.Pedidos.ToList().IndexOf(_pedidoAtual);
        AtualizarItens();
    }

    private void AtualizarItens()
    {
        _listaItens.Items.Clear();
        if (_pedidoAtual is null) { _resumo.Text = "Nenhum pedido selecionado."; return; }
        foreach (var item in _pedidoAtual.Itens) _listaItens.Items.Add(item);
        _resumo.Text = $"Pedido #{_pedidoAtual.Id} — Total: {_pedidoAtual.CalcularTotal():C}";
    }

    private static string? SolicitarTexto(string titulo, string mensagem)
    {
        using var dialogo = new Form { Text = titulo, Width = 420, Height = 155, StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog, MinimizeBox = false, MaximizeBox = false };
        var label = new Label { Text = mensagem, AutoSize = true, Location = new Point(15, 15) };
        var caixa = new TextBox { Location = new Point(15, 43), Width = 370 };
        var ok = new Button { Text = "OK", DialogResult = DialogResult.OK, Location = new Point(230, 78), Width = 75 };
        var cancelar = new Button { Text = "Cancelar", DialogResult = DialogResult.Cancel, Location = new Point(310, 78), Width = 75 };
        dialogo.Controls.AddRange(new Control[] { label, caixa, ok, cancelar });
        dialogo.AcceptButton = ok;
        dialogo.CancelButton = cancelar;
        return dialogo.ShowDialog() == DialogResult.OK ? caixa.Text.Trim() : null;
    }

    private static void Avisar(string mensagem) => MessageBox.Show(mensagem, "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
    private static void Informar(string mensagem) => MessageBox.Show(mensagem, "Projeto Restaurante", MessageBoxButtons.OK, MessageBoxIcon.Information);
}
