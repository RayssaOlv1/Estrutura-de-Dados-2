using System.Text.Json;

namespace ControleAcessos.Models;

public class Cadastro
{
    public List<Usuario> Usuarios { get; set; } = new();
    public List<Ambiente> Ambientes { get; set; } = new();

    public void AdicionarUsuario(Usuario usuario) => Usuarios.Add(usuario);
    public bool RemoverUsuario(Usuario usuario)
    {
        if (usuario.Ambientes.Count > 0) return false;
        return Usuarios.Remove(usuario);
    }
    public Usuario? PesquisarUsuario(string nome) =>
        Usuarios.FirstOrDefault(u => u.Nome.Equals(nome, StringComparison.OrdinalIgnoreCase));
    public void AdicionarAmbiente(Ambiente ambiente) => Ambientes.Add(ambiente);
    public bool RemoverAmbiente(Ambiente ambiente)
    {
        foreach (var usuario in Usuarios)
            usuario.RevogarPermissao(ambiente);
        return Ambientes.Remove(ambiente);
    }
    public Ambiente? PesquisarAmbiente(string nome) =>
        Ambientes.FirstOrDefault(a => a.Nome.Equals(nome, StringComparison.OrdinalIgnoreCase));

    public void Upload(string caminho)
    {
        var opcoes = new JsonSerializerOptions { WriteIndented = true };
        File.WriteAllText(caminho, JsonSerializer.Serialize(this, opcoes));
    }

    public static Cadastro Download(string caminho)
    {
        if (!File.Exists(caminho)) return new Cadastro();
        try
        {
            var cadastro = JsonSerializer.Deserialize<Cadastro>(File.ReadAllText(caminho));
            if (cadastro == null) return new Cadastro();
            foreach (var ambiente in cadastro.Ambientes)
                ambiente.Logs ??= new Queue<Log>();
            foreach (var usuario in cadastro.Usuarios)
                usuario.Ambientes ??= new List<Ambiente>();
            return cadastro;
        }
        catch (JsonException) { return new Cadastro(); }
    }
}
