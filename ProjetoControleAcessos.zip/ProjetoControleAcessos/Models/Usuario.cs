namespace ControleAcessos.Models;

public class Usuario
{
    public int Id { get; set; }
    public string Nome { get; set; } = string.Empty;
    public List<Ambiente> Ambientes { get; set; } = new();

    public bool ConcederPermissao(Ambiente ambiente)
    {
        if (Ambientes.Any(a => a.Id == ambiente.Id)) return false;
        Ambientes.Add(ambiente);
        return true;
    }

    public bool RevogarPermissao(Ambiente ambiente)
    {
        var existente = Ambientes.FirstOrDefault(a => a.Id == ambiente.Id);
        return existente != null && Ambientes.Remove(existente);
    }
}
