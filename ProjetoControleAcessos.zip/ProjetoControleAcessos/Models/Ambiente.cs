namespace ControleAcessos.Models;

public class Ambiente
{
    public int Id { get; set; }
    public string Nome { get; set; } = string.Empty;
    public Queue<Log> Logs { get; set; } = new();

    public void RegistrarLog(Log log)
    {
        while (Logs.Count >= 100) Logs.Dequeue();
        Logs.Enqueue(log);
    }
}
