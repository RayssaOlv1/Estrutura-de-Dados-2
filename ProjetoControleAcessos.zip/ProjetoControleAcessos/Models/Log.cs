namespace ControleAcessos.Models;

public class Log
{
    public DateTime DtAcesso { get; set; }
    public int UsuarioId { get; set; }
    public string UsuarioNome { get; set; } = string.Empty;
    public bool TipoAcesso { get; set; }
}
