using ControleAcessos.Models;
using System.Drawing;

namespace ControleAcessos;

public class MainForm : Form
{
    private readonly Cadastro cadastro;
    private readonly string arquivoDados = Path.Combine(AppContext.BaseDirectory, "dados.json");
    private readonly Panel conteudo = new();
    private readonly Label titulo = new();
    private readonly ListBox menu = new();

    public MainForm()
    {
        cadastro = Cadastro.Download(arquivoDados);
        Text = "Controle de Acessos";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(960, 620);
        Size = new Size(1120, 700);
        BackColor = Color.FromArgb(247, 249, 248);
        FormClosing += (_, _) => cadastro.Upload(arquivoDados);
        CriarLayout();
        menu.SelectedIndex = 1;
    }

    private void CriarLayout()
    {
        var cabecalho = new Panel { Dock = DockStyle.Top, Height = 76, BackColor = Color.FromArgb(18, 78, 70) };
        var marca = new Label { Text = "CONTROLE DE ACESSOS", ForeColor = Color.White, Font = new Font("Segoe UI", 18, FontStyle.Bold), AutoSize = true, Location = new Point(25, 17) };
        var subtitulo = new Label { Text = "Gerenciamento de ambientes, usuários e registros", ForeColor = Color.FromArgb(205, 230, 224), AutoSize = true, Location = new Point(28, 48) };
        cabecalho.Controls.AddRange(new Control[] { marca, subtitulo });

        var lateral = new Panel { Dock = DockStyle.Left, Width = 280, Padding = new Padding(15), BackColor = Color.White };
        var menuTitulo = new Label { Text = "OPÇÕES DO SELETOR", Font = new Font("Segoe UI", 10, FontStyle.Bold), ForeColor = Color.FromArgb(18, 78, 70), Dock = DockStyle.Top, Height = 35 };
        menu.Dock = DockStyle.Fill;
        menu.Font = new Font("Segoe UI", 10);
        menu.BorderStyle = BorderStyle.None;
        menu.ItemHeight = 38;
        menu.IntegralHeight = false;
        menu.Items.AddRange(new object[] { "0. Sair", "1. Cadastrar ambiente", "2. Consultar ambiente", "3. Excluir ambiente", "4. Cadastrar usuário", "5. Consultar usuário", "6. Excluir usuário", "7. Conceder permissão", "8. Revogar permissão", "9. Registrar acesso", "10. Consultar logs" });
        menu.SelectedIndexChanged += (_, _) => SelecionarOperacao(menu.SelectedIndex);
        lateral.Controls.Add(menu);
        lateral.Controls.Add(menuTitulo);

        conteudo.Dock = DockStyle.Fill;
        conteudo.Padding = new Padding(28);
        titulo.Dock = DockStyle.Top;
        titulo.Height = 46;
        titulo.Font = new Font("Segoe UI", 18, FontStyle.Bold);
        titulo.ForeColor = Color.FromArgb(18, 78, 70);
        conteudo.Controls.Add(titulo);

        Controls.Add(conteudo);
        Controls.Add(lateral);
        Controls.Add(cabecalho);
    }

    private void SelecionarOperacao(int indice)
    {
        if (indice == 0) { Close(); return; }
        conteudo.Controls.Clear();
        conteudo.Controls.Add(titulo);
        titulo.Text = menu.Items[indice]?.ToString()?.Substring(3) ?? "";
        switch (indice)
        {
            case 1: MostrarCadastroAmbiente(); break;
            case 2: MostrarConsultaAmbiente(); break;
            case 3: MostrarExclusaoAmbiente(); break;
            case 4: MostrarCadastroUsuario(); break;
            case 5: MostrarConsultaUsuario(); break;
            case 6: MostrarExclusaoUsuario(); break;
            case 7: MostrarPermissao(true); break;
            case 8: MostrarPermissao(false); break;
            case 9: MostrarRegistrarAcesso(); break;
            case 10: MostrarLogs(); break;
        }
    }

    private void LimparAbaixoTitulo() { while (conteudo.Controls.Count > 1) conteudo.Controls.RemoveAt(1); }
    private Label Texto(string valor) => new() { Text = valor, AutoSize = true, Font = new Font("Segoe UI", 10), Margin = new Padding(0, 8, 0, 5) };
    private TextBox Campo(string placeholder = "") => new() { Width = 430, Height = 32, Font = new Font("Segoe UI", 10), PlaceholderText = placeholder };
    private Button Botao(string texto) => new() { Text = texto, AutoSize = true, Height = 36, Padding = new Padding(16, 2, 16, 2), BackColor = Color.FromArgb(18, 78, 70), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
    private ComboBox Seletor<T>(IEnumerable<T> itens, Func<T, string> texto) where T : class
    {
        var combo = new ComboBox { Width = 430, DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 10), DisplayMember = "TextoExibicao" };
        foreach (var item in itens) combo.Items.Add(new ItemCombo<T>(item, texto(item)));
        if (combo.Items.Count > 0) combo.SelectedIndex = 0;
        return combo;
    }
    private sealed record ItemCombo<T>(T Valor, string TextoExibicao) where T : class;
    private T? Valor<T>(ComboBox combo) where T : class => (combo.SelectedItem as ItemCombo<T>)?.Valor;
    private void Mensagem(string texto, bool erro = false) => MessageBox.Show(texto, erro ? "Atenção" : "Controle de Acessos", MessageBoxButtons.OK, erro ? MessageBoxIcon.Warning : MessageBoxIcon.Information);

    private void MostrarCadastroAmbiente()
    {
        LimparAbaixoTitulo(); var painel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true };
        var nome = Campo("Nome do ambiente"); var salvar = Botao("Cadastrar ambiente");
        salvar.Click += (_, _) => { if (string.IsNullOrWhiteSpace(nome.Text)) { Mensagem("Informe o nome do ambiente.", true); return; } if (cadastro.PesquisarAmbiente(nome.Text) != null) { Mensagem("Já existe um ambiente com esse nome.", true); return; } cadastro.AdicionarAmbiente(new Ambiente { Id = ProximoIdAmbiente(), Nome = nome.Text.Trim() }); cadastro.Upload(arquivoDados); nome.Clear(); Mensagem("Ambiente cadastrado com sucesso."); };
        painel.Controls.AddRange(new Control[] { Texto("Nome do ambiente"), nome, salvar }); conteudo.Controls.Add(painel);
    }

    private void MostrarConsultaAmbiente()
    {
        LimparAbaixoTitulo(); var tabela = TabelaAmbientes(); conteudo.Controls.Add(tabela);
    }
    private DataGridView TabelaAmbientes()
    {
        var grid = Grade(); grid.Columns.Add("Id", "ID"); grid.Columns.Add("Nome", "Nome"); grid.Columns.Add("Logs", "Logs registrados");
        foreach (var a in cadastro.Ambientes) grid.Rows.Add(a.Id, a.Nome, a.Logs.Count); return grid;
    }
    private void MostrarExclusaoAmbiente()
    {
        LimparAbaixoTitulo(); var painel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false }; var combo = Seletor(cadastro.Ambientes, a => $"{a.Id} - {a.Nome}"); var botao = Botao("Excluir ambiente");
        botao.Click += (_, _) => { var ambiente = Valor<Ambiente>(combo); if (ambiente == null) return; if (MessageBox.Show($"Excluir '{ambiente.Nome}'?", "Confirmação", MessageBoxButtons.YesNo) != DialogResult.Yes) return; cadastro.RemoverAmbiente(ambiente); cadastro.Upload(arquivoDados); Mensagem("Ambiente removido com sucesso."); MostrarExclusaoAmbiente(); };
        painel.Controls.AddRange(new Control[] { Texto("Selecione o ambiente"), combo, botao }); conteudo.Controls.Add(painel);
    }

    private void MostrarCadastroUsuario()
    {
        LimparAbaixoTitulo(); var painel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false }; var nome = Campo("Nome do usuário"); var salvar = Botao("Cadastrar usuário");
        salvar.Click += (_, _) => { if (string.IsNullOrWhiteSpace(nome.Text)) { Mensagem("Informe o nome do usuário.", true); return; } if (cadastro.PesquisarUsuario(nome.Text) != null) { Mensagem("Já existe um usuário com esse nome.", true); return; } cadastro.AdicionarUsuario(new Usuario { Id = ProximoIdUsuario(), Nome = nome.Text.Trim() }); cadastro.Upload(arquivoDados); nome.Clear(); Mensagem("Usuário cadastrado com sucesso."); };
        painel.Controls.AddRange(new Control[] { Texto("Nome do usuário"), nome, salvar }); conteudo.Controls.Add(painel);
    }
    private void MostrarConsultaUsuario()
    {
        LimparAbaixoTitulo(); var grid = Grade(); grid.Columns.Add("Id", "ID"); grid.Columns.Add("Nome", "Nome"); grid.Columns.Add("Permissoes", "Ambientes autorizados"); foreach (var u in cadastro.Usuarios) grid.Rows.Add(u.Id, u.Nome, string.Join(", ", u.Ambientes.Select(a => a.Nome))); conteudo.Controls.Add(grid);
    }
    private void MostrarExclusaoUsuario()
    {
        LimparAbaixoTitulo(); var painel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false }; var combo = Seletor(cadastro.Usuarios, u => $"{u.Id} - {u.Nome}"); var botao = Botao("Excluir usuário");
        botao.Click += (_, _) => { var usuario = Valor<Usuario>(combo); if (usuario == null) return; if (usuario.Ambientes.Count > 0) { Mensagem("O usuário só pode ser removido se não tiver nenhuma permissão de acesso.", true); return; } cadastro.RemoverUsuario(usuario); cadastro.Upload(arquivoDados); Mensagem("Usuário removido com sucesso."); MostrarExclusaoUsuario(); };
        painel.Controls.AddRange(new Control[] { Texto("Selecione o usuário"), combo, botao }); conteudo.Controls.Add(painel);
    }

    private void MostrarPermissao(bool conceder)
    {
        LimparAbaixoTitulo(); var painel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false }; var usuario = Seletor(cadastro.Usuarios, u => $"{u.Id} - {u.Nome}"); var ambiente = Seletor(cadastro.Ambientes, a => $"{a.Id} - {a.Nome}"); var botao = Botao(conceder ? "Conceder permissão" : "Revogar permissão");
        botao.Click += (_, _) => { var u = Valor<Usuario>(usuario); var a = Valor<Ambiente>(ambiente); if (u == null || a == null) { Mensagem("Cadastre um usuário e um ambiente antes de continuar.", true); return; } var resultado = conceder ? u.ConcederPermissao(a) : u.RevogarPermissao(a); if (!resultado) { Mensagem(conceder ? "O usuário já possui essa permissão." : "O usuário não possui essa permissão.", true); return; } cadastro.Upload(arquivoDados); Mensagem(conceder ? "Permissão concedida." : "Permissão revogada."); };
        painel.Controls.AddRange(new Control[] { Texto("Usuário"), usuario, Texto("Ambiente"), ambiente, botao }); conteudo.Controls.Add(painel);
    }

    private void MostrarRegistrarAcesso()
    {
        LimparAbaixoTitulo(); var painel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false }; var usuario = Seletor(cadastro.Usuarios, u => $"{u.Id} - {u.Nome}"); var ambiente = Seletor(cadastro.Ambientes, a => $"{a.Id} - {a.Nome}"); var botao = Botao("Registrar acesso");
        botao.Click += (_, _) => { var u = Valor<Usuario>(usuario); var a = Valor<Ambiente>(ambiente); if (u == null || a == null) { Mensagem("Cadastre um usuário e um ambiente antes de continuar.", true); return; } var autorizado = u.Ambientes.Any(x => x.Id == a.Id); a.RegistrarLog(new Log { DtAcesso = DateTime.Now, UsuarioId = u.Id, UsuarioNome = u.Nome, TipoAcesso = autorizado }); cadastro.Upload(arquivoDados); Mensagem(autorizado ? "Acesso autorizado e registrado." : "Acesso negado e registrado."); };
        painel.Controls.AddRange(new Control[] { Texto("Usuário"), usuario, Texto("Ambiente"), ambiente, botao }); conteudo.Controls.Add(painel);
    }

    private void MostrarLogs()
    {
        LimparAbaixoTitulo(); var topo = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 78, FlowDirection = FlowDirection.LeftToRight }; var ambiente = Seletor(cadastro.Ambientes, a => $"{a.Id} - {a.Nome}"); var filtro = new ComboBox { Width = 150, DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 10) }; filtro.Items.AddRange(new object[] { "Todos", "Autorizados", "Negados" }); filtro.SelectedIndex = 0; var consultar = Botao("Consultar"); var grid = Grade(); grid.Columns.Add("Data", "Data/hora"); grid.Columns.Add("Usuario", "Usuário"); grid.Columns.Add("Resultado", "Resultado");
        void Atualizar() { grid.Rows.Clear(); var a = Valor<Ambiente>(ambiente); if (a == null) return; foreach (var log in a.Logs) { if (filtro.SelectedIndex == 1 && !log.TipoAcesso || filtro.SelectedIndex == 2 && log.TipoAcesso) continue; grid.Rows.Add(log.DtAcesso.ToString("dd/MM/yyyy HH:mm:ss"), log.UsuarioNome, log.TipoAcesso ? "Autorizado" : "Negado"); } }
        consultar.Click += (_, _) => Atualizar(); topo.Controls.AddRange(new Control[] { Texto("Ambiente"), ambiente, filtro, consultar }); conteudo.Controls.Add(grid); conteudo.Controls.Add(topo); Atualizar();
    }

    private DataGridView Grade() => new() { Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, BackgroundColor = Color.White, BorderStyle = BorderStyle.FixedSingle, Font = new Font("Segoe UI", 10), RowHeadersVisible = false };
    private int ProximoIdAmbiente() => cadastro.Ambientes.Count == 0 ? 1 : cadastro.Ambientes.Max(a => a.Id) + 1;
    private int ProximoIdUsuario() => cadastro.Usuarios.Count == 0 ? 1 : cadastro.Usuarios.Max(u => u.Id) + 1;
}
