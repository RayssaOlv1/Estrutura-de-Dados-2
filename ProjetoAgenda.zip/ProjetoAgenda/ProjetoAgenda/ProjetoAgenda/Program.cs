using ProjetoAgenda.Models;

namespace ProjetoAgenda;

internal static class Program
{
    private static readonly Contatos Agenda = new();

    private static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        var sair = false;
        while (!sair)
        {
            ExibirMenu();
            switch (LerInteiro("Escolha uma opção: "))
            {
                case 0: sair = true; break;
                case 1: AdicionarContato(); break;
                case 2: PesquisarContato(); break;
                case 3: AlterarContato(); break;
                case 4: RemoverContato(); break;
                case 5: ListarContatos(); break;
                default: Avisar("Opção inválida."); break;
            }
            if (!sair) Pausar();
        }
        Console.WriteLine("Programa encerrado.");
    }

    private static void ExibirMenu()
    {
        Console.Clear();
        Console.WriteLine("====================================");
        Console.WriteLine("          AGENDA DE CONTATOS");
        Console.WriteLine("====================================");
        Console.WriteLine("0. Sair");
        Console.WriteLine("1. Adicionar contato");
        Console.WriteLine("2. Pesquisar contato");
        Console.WriteLine("3. Alterar contato");
        Console.WriteLine("4. Remover contato");
        Console.WriteLine("5. Listar contatos");
        Console.WriteLine("====================================");
    }

    private static void AdicionarContato()
    {
        Cabecalho("ADICIONAR CONTATO");
        var nome = LerTexto("Nome: ");
        var email = LerTexto("E-mail: ");
        var nascimento = LerData("Data de nascimento");
        var contato = new Contato(email, nome, nascimento);
        AdicionarTelefones(contato);
        if (Agenda.Adicionar(contato)) Informar("Contato adicionado com sucesso.");
        else Avisar("Já existe um contato com este e-mail.");
    }

    private static void PesquisarContato()
    {
        Cabecalho("PESQUISAR CONTATO");
        var contato = LocalizarContato();
        if (contato is null) Avisar("Contato não encontrado.");
        else ExibirContato(contato);
    }

    private static void AlterarContato()
    {
        Cabecalho("ALTERAR CONTATO");
        var atual = LocalizarContato();
        if (atual is null) { Avisar("Contato não encontrado."); return; }

        Console.WriteLine("Deixe em branco para manter o valor atual.");
        var nome = LerTextoOpcional($"Nome [{atual.Nome}]: ");
        var email = LerTextoOpcional($"E-mail [{atual.Email}]: ");
        var novaData = LerDataOpcional($"Data de nascimento [{atual.DtNasc}]: ");
        if (nome is not null) atual.Nome = nome;
        if (email is not null) atual.Email = email;
        if (novaData is not null) atual.DtNasc = novaData;

        Console.Write("Deseja adicionar um novo telefone? (s/n): ");
        if (Console.ReadLine()?.Trim().Equals("s", StringComparison.OrdinalIgnoreCase) == true)
            AdicionarTelefones(atual);

        Informar("Contato alterado com sucesso.");
    }

    private static void RemoverContato()
    {
        Cabecalho("REMOVER CONTATO");
        var contato = LocalizarContato();
        if (contato is null) { Avisar("Contato não encontrado."); return; }
        ExibirContato(contato);
        Console.Write("Confirma a remoção? (s/n): ");
        if (Console.ReadLine()?.Trim().Equals("s", StringComparison.OrdinalIgnoreCase) == true)
            Informar(Agenda.Remover(contato) ? "Contato removido." : "Não foi possível remover o contato.");
        else Informar("Remoção cancelada.");
    }

    private static void ListarContatos()
    {
        Cabecalho("LISTAR CONTATOS");
        if (Agenda.Agenda.Count == 0) { Console.WriteLine("Nenhum contato cadastrado."); return; }
        for (var i = 0; i < Agenda.Agenda.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {Agenda.Agenda[i]}");
            foreach (var telefone in Agenda.Agenda[i].Telefones) Console.WriteLine($"   - {telefone}");
        }
    }

    private static Contato? LocalizarContato()
    {
        var busca = LerTexto("Informe o e-mail ou nome: ");
        return Agenda.Agenda.FirstOrDefault(c => c.Email.Equals(busca, StringComparison.OrdinalIgnoreCase) || c.Nome.Contains(busca, StringComparison.OrdinalIgnoreCase));
    }

    private static void AdicionarTelefones(Contato contato)
    {
        do
        {
            var tipo = LerTexto("Tipo do telefone (celular, residencial...): ");
            var numero = LerTexto("Número: ");
            var principal = LerSimNao("É o telefone principal? (s/n): ");
            contato.AdicionarTelefone(new Telefone(tipo, numero, principal));
            Console.Write("Adicionar outro telefone? (s/n): ");
        } while (Console.ReadLine()?.Trim().Equals("s", StringComparison.OrdinalIgnoreCase) == true);
    }

    private static Data LerData(string rotulo)
    {
        while (true)
        {
            Console.WriteLine($"{rotulo} (dia, mês e ano):");
            var dia = LerInteiro("Dia: ");
            var mes = LerInteiro("Mês: ");
            var ano = LerInteiro("Ano: ");
            try { return new Data(dia, mes, ano); }
            catch (ArgumentException ex) { Avisar(ex.Message); }
        }
    }

    private static Data? LerDataOpcional(string rotulo)
    {
        Console.WriteLine(rotulo);
        var texto = Console.ReadLine()?.Trim();
        if (string.IsNullOrEmpty(texto)) return null;
        var partes = texto.Split('/', '-', StringSplitOptions.RemoveEmptyEntries);
        if (partes.Length == 3 && int.TryParse(partes[0], out var dia) && int.TryParse(partes[1], out var mes) && int.TryParse(partes[2], out var ano))
        {
            try { return new Data(dia, mes, ano); } catch (ArgumentException) { }
        }
        Avisar("Data inválida. A data anterior será mantida.");
        return null;
    }

    private static int LerInteiro(string mensagem)
    {
        while (true)
        {
            Console.Write(mensagem);
            if (int.TryParse(Console.ReadLine(), out var valor)) return valor;
            Avisar("Digite um número inteiro válido.");
        }
    }

    private static string LerTexto(string mensagem)
    {
        while (true)
        {
            Console.Write(mensagem);
            var valor = Console.ReadLine()?.Trim();
            if (!string.IsNullOrWhiteSpace(valor)) return valor;
            Avisar("Este campo é obrigatório.");
        }
    }

    private static string? LerTextoOpcional(string mensagem)
    {
        Console.Write(mensagem);
        var valor = Console.ReadLine()?.Trim();
        return string.IsNullOrEmpty(valor) ? null : valor;
    }

    private static bool LerSimNao(string mensagem)
    {
        Console.Write(mensagem);
        return Console.ReadLine()?.Trim().Equals("s", StringComparison.OrdinalIgnoreCase) == true;
    }

    private static void ExibirContato(Contato contato)
    {
        Console.WriteLine();
        Console.WriteLine(contato);
        foreach (var telefone in contato.Telefones) Console.WriteLine($"  - {telefone}");
    }

    private static void Cabecalho(string titulo) 
    { 
        Console.Clear(); 
        Console.WriteLine($"--- {titulo} ---"); 
        Console.WriteLine(); 
    }
    private static void Avisar(string mensagem) => Console.WriteLine($"[Atenção] {mensagem}");
    private static void Informar(string mensagem) => Console.WriteLine($"[OK] {mensagem}");
    private static void Pausar() { Console.WriteLine(); Console.Write("Pressione ENTER para continuar..."); Console.ReadLine(); }
}
